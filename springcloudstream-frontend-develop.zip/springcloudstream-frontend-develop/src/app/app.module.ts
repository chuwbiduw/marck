import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { NavComponent } from './views/nav/nav.component';
import { MainComponent } from './views/main/main.component';
import { SidebarComponent } from './views/sidebar/sidebar.component';
import { DashboardComponent } from './views/dashboard/dashboard.component';
import { ChartsModule } from 'ng2-charts';
import { DetailComponent } from './views/detail/detail.component';

@NgModule({
  declarations: [
    NavComponent,
    MainComponent,
    SidebarComponent,
    DashboardComponent,
    DetailComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ChartsModule
  ],
  providers: [],
  bootstrap: [MainComponent]
})
export class AppModule { }
