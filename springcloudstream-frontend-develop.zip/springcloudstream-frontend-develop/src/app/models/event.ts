import { MicroServiceItem } from './microservice';

export class EventItem {
    private _id: string;
    public get id(): string {
        return this._id;
    }
    public set id(value: string) {
        this._id = value;
    }
    private _name: string;
    public get name(): string {
        return this._name;
    }
    public set name(value: string) {
        this._name = value;
    }
    private _source: MicroServiceItem;
    public get source(): MicroServiceItem {
        return this._source;
    }
    public set source(value: MicroServiceItem) {
        this._source = value;
    }
    private _dest: MicroServiceItem;
    public get dest(): MicroServiceItem {
        return this._dest;
    }
    public set dest(value: MicroServiceItem) {
        this._dest = value;
    }
    private _item: any;
    public get item(): any {
        return this._item;
    }
    public set item(value: any) {
        this._item = value;
    }

    constructor(options: any) {
        this.id = options.id;
        this.name = options.name;
        this.source = options.source;
        this.dest = options.dest;
        this.item = options.item;
    }

}


