import { registerLocaleData } from '@angular/common';

export class MicroServiceItem {
    private _name: string;
    public get name(): string {
        return this._name;
    }
    public set name(value: string) {
        this._name = value;
    }
    private _desc: string;
    public get desc(): string {
        return this._desc;
    }
    public set desc(value: string) {
        this._desc = value;
    }
    private _status: string;
    public get status(): string {
        return this._status;
    }
    public set status(value: string) {
        this._status = value;
    }
    private _url: string;
    public get url(): string {
        return this._url;
    }
    public set url(value: string) {
        this._url = value;
    }


    constructor(options: any) {
        this.name = options.name;
        this.desc = options.desc;
        this.status = options.status;
        this.url = options.name.toLowerCase() + 'cloud-server.open-groupe.com';
    }


}


