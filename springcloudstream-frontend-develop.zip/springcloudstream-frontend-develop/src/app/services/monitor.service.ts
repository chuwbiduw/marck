import { Injectable } from '@angular/core';
import { MicroServiceItem } from '../models/microservice';
import { EventItem } from '../models/event';
import * as _ from 'underscore';
import { Observable } from 'rxjs';



@Injectable({
  providedIn: 'root'
})
export class MonitorService {
  private ms1: MicroServiceItem;

  private ms2: MicroServiceItem;

  private ms3: MicroServiceItem;

  private list: EventItem[];

  private _endpoints: MicroServiceItem[];


  constructor() {
    // settings
    this.ms1 = new MicroServiceItem({
      name: 'MS1',
      desc: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed non risus. Suspendisse lectus tortor, dignissim sit amet, adipiscing nec, ultricies sed, dolor. Cras elementum ultrices diam. Maecenas ligula massa, varius a, semper congue, euismod non, mi. Proin porttitor, orci nec nonummy molestie, enim est eleifend mi, non fermentum diam nisl sit amet erat. Duis semper. Duis arcu massa, scelerisque vitae, consequat in, pretium a, enim. Pellentesque congue. Ut in risus volutpat libero pharetra tempor. Cras vestibulum bibendum augue. Praesent egestas leo in pede. Praesent blandit odio eu enim. Pellentesque sed dui ut augue blandit sodales. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Aliquam nibh. Mauris ac mauris sed pede pellentesque fermentum. Maecenas adipiscing ante non diam sodales hendrerit.',
      status: 'RUNNING'
    });
    this.ms2 = new MicroServiceItem({
      name: 'MS2',
      desc: 'At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat.',
      status: 'RUNNING'
    });
    this.ms3 = new MicroServiceItem({
      name: 'MS3',
      desc: 'Dum apud Persas, ut supra narravimus, perfidia regis motus agitat insperatos, et in eois tractibus bella rediviva consurgunt, anno sexto decimo et eo diutius post Nepotiani exitium, saeviens per urbem aeternam urebat cuncta Bellona, ex primordiis minimis ad clades excita luctuosas, quas obliterasset utinam iuge silentium! ne forte paria quandoque temptentur, plus exemplis generalibus nocitura quam delictis. Quibus occurrere bene pertinax miles explicatis ordinibus parans hastisque feriens scuta qui habitus iram pugnantium concitat et dolorem proximos iam gestu terrebat sed eum in certamen alacriter consurgentem revocavere ductores rati intempestivum anceps subire certamen cum haut longe muri distarent, quorum tutela securitas poterat in solido locari cunctorum.',
      status: 'RUNNING'
    });
    this.list = [];
    this.endpoints = [this.ms1, this.ms2, this.ms3];
  }

  public get $events(): Observable<EventItem> {

    return new Observable((observer) => {
      setInterval(() => {
        const method = ['update', 'create', 'cancel'];
        const random = _.sample(this.endpoints, 2);
        observer.next(new EventItem({
          id: this.list.length,
          name: _.sample(method),
          source: random[0],
          dest: random[1],
        }))
      }, 2000)
    });
  }

  public get endpoints(): MicroServiceItem[] {
    return this._endpoints;
  }
  public set endpoints(value: MicroServiceItem[]) {
    this._endpoints = value;
  }
}
