import { Component, Input, OnInit } from '@angular/core';
import { MonitorService } from 'src/app/services/monitor.service';
import { MicroServiceItem } from 'src/app/models/microservice';
import * as _ from 'underscore';
import * as Feather from 'feather-icons';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css']
})
export class SidebarComponent implements OnInit {

  private _items: MicroServiceItem[];

  _event: Event;
  toogle: boolean;

  constructor(private monitor: MonitorService) {
  }

  @Input() set event(value: Event) {
    if (value) {
      this.toogle = !this.toogle;
    } else {
      this.toogle = false;
    }
  }

  @Input() set keypress(value: string) {
    if (value) {
      this.items = _.filter(this.monitor.endpoints, (item) => {
        return item.name.toLocaleLowerCase().includes(value.toLocaleLowerCase());
      });
    } else {
      this.items = this.monitor.endpoints;
    }
    setTimeout(Feather.replace, 0);
  }

  onClick() {
    this.toogle = false;
  }


  public get items(): MicroServiceItem[] {
    return this._items;
  }

  public set items(value: MicroServiceItem[]) {
    this._items = value;
  }

  ngOnInit(): void {
    this.items = this.monitor.endpoints;
  }


}
