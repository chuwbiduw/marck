import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { SidebarComponent } from '../sidebar/sidebar.component';

@Component({
  selector: 'app-nav',
  templateUrl: './nav.component.html',
  styleUrls: ['./nav.component.css']
})
export class NavComponent implements OnInit {

  @Output() eventClicked = new EventEmitter<Event>();
  @Output() eventKeyUp = new EventEmitter<Event>();

  constructor() { }

  ngOnInit(): void {
  }

  onClick(event) {
    this.eventClicked.emit(event);
  }
  keyUP(search) {
    this.eventKeyUp.emit((search as any).value);
  }
}
