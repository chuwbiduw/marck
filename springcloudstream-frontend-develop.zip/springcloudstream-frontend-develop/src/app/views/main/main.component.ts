import { Component, OnInit, AfterViewInit } from '@angular/core';
import * as Feather from 'feather-icons';

@Component({
  selector: 'app-root',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.css']
})
export class MainComponent implements OnInit, AfterViewInit {
  public clickedEvent: Event;
  public keyupEvent: Event;

  childEventClicked(event: Event) {
    this.clickedEvent = event;
  }

  childEventKeyUp(event: Event) {
    this.keyupEvent = event;
  }

  constructor() { }

  ngAfterViewInit(): void {
    Feather.replace();
  }

  ngOnInit(): void {
  }

}
