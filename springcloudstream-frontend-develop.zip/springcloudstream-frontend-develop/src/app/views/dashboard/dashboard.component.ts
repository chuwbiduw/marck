import { Component, OnInit } from '@angular/core';
import { MonitorService } from 'src/app/services/monitor.service';
import { EventItem } from 'src/app/models/event';
import * as _ from 'underscore';

interface Dictionary<T> {
  [Key: string]: T;
}

@Component({
  // tslint:disable-next-line: component-selector
  selector: 'app-dash',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  public headers: string[] = ['#', 'name', 'source', 'destination', 'product'];
  public rows: EventItem[] = [];
  private listIn: number[] = [0, 0, 0];
  private listOut: number[] = [0, 0, 0];

  public pieChartLabels: string[];

  public pieChartDatasets: any[];
  public pieChartType: string;
  public pieChartOptions: any;

  constructor(private monitor: MonitorService) {
    this.pieChartLabels = _.map(this.monitor.endpoints, item => item.name);
    this.pieChartDatasets = [
      { data: this.listIn, label: 'Event in' },
      { data: this.listOut, label: 'Event out' }
    ];
    this.pieChartType = 'bar';
    this.pieChartOptions = {
      animation: {
        duration: 0
      },
      scales: {
        yAxes: [{
          ticks: {
            beginAtZero: true
          }
        }]
      },
      legend: {
        display: true,
        labels: {
          fontColor: 'rgb(255, 99, 132)'
        }
      }
    };
  }

  ngOnInit(): void {
    this.compute()
  }

  // events on slice click
  public chartClicked(e: any): void {
  }

  // event on pie chart slice hover
  public chartHovered(e: any): void {
  }


  compute(): void {
    this.monitor.$events.subscribe((event) => {
      this.rows.push(event);
      [{ name: event.source.name, list: this.listIn },
      { name: event.dest.name, list: this.listOut }].map((item) => {
        item.list[this.monitor.endpoints.findIndex(i => i.name === item.name)] += 1;
      })
      this.update();
    })
  }

  update(): void {
    this.pieChartDatasets = [
      { data: this.listIn, label: 'Event in' },
      { data: this.listOut, label: 'Event out' }
    ];
  }

}
