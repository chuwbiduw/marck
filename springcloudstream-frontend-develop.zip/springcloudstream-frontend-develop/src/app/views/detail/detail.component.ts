import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { MonitorService } from 'src/app/services/monitor.service';
import { MicroServiceItem } from 'src/app/models/microservice';
import * as _ from 'underscore';

@Component({
  selector: 'app-detail',
  templateUrl: './detail.component.html',
  styleUrls: ['./detail.component.css']
})
export class DetailComponent implements OnInit {
  private _ms: MicroServiceItem;

  public get ms(): MicroServiceItem {
    return this._ms;
  }
  public set ms(value: MicroServiceItem) {
    this._ms = value;
  }

  constructor(private route: ActivatedRoute, private monitor: MonitorService) {
    console.log(route);
    this.route.params.subscribe((val) => {
      this.ms = _.first(this.monitor.endpoints.filter((item) => {
        return item.name === val.id;
      }));
    });
  }

  ngOnInit(): void {

  }

}
